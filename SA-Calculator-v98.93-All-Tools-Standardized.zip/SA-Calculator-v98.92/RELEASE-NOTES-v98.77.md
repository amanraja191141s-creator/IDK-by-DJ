# SA Calculator v98.77 — Action-Time Hardening

## Scope
Fresh rebuild from v98.76 with additional action-time lifecycle hardening against stale results, accidental auto-commit, and reference-visible tenure formatting mismatches.

## Fixes
- Centralized tool-result invalidation for explicit `=` / Calculate workflows.
- Editing a committed result now invalidates the old result before the next calculation.
- Age Calculator no longer auto-commits when the native date picker changes the date; result appears only after Calculate.
- BMI unit/gender changes invalidate a previously committed result before recalculation.
- GST mode, place-of-supply, and quick-rate changes invalidate the committed result lifecycle.
- Percent mode changes invalidate the previous committed result lifecycle.
- Loan tenure picker changes invalidate the submitted loan result.
- Loan tenure display now matches the supplied reference more closely: `1years` instead of `1years 0months` when months are zero.
- Persisted loan tenure restores through the same compact formatter.
- Existing Currency/Unit live-converter behavior remains live and is not incorrectly gated by the result lifecycle.
- Added action-time regression coverage for lifecycle invalidation, Age, BMI, GST, Loan, and result visibility.
- Regenerated the Android `www/` bundle and synchronized root/Android assets.
- Bumped release identity to `1.98.91-v98.77`, Android versionCode `1098701`, and a fresh service-worker cache namespace.

## Validation
- `npm test`: 76/76 passing.
- JavaScript syntax checks passing.
- YAML parsing passing for standalone and GitHub workflow.
- Root and `www/` HTML/JS/CSS/service-worker assets byte-identical.
- ZIP integrity checked after packaging.
