import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
const root=path.resolve(path.dirname(new URL(import.meta.url).pathname),'..');
const html=fs.readFileSync(path.join(root,'index.html'),'utf8');
const js=fs.readFileSync(path.join(root,'assets/js/app.js'),'utf8');
const css=fs.readFileSync(path.join(root,'assets/css/tool-reference-ui.css'),'utf8');

test('shared tool keypad has no undefined screenId runtime reference',()=>{
  assert.doesNotMatch(js,/if \(screenId === 'currencies'\) \{\s*const refitCurrency/);
  assert.match(js,/if \(STATE\.currentScreen === 'currencies'\) \{\s*const refitCurrency/);
});

test('reference-video unit converter opens with workspace and category chips',()=>{
  assert.match(html,/id="unit-category-chooser"/);
  assert.match(html,/id="unit-converter-workspace"(?! hidden)/);
  assert.match(js,/if \(workspace\) workspace\.hidden = false;/);
});

test('reference-video age and BMI result structures are present',()=>{
  for(const id of ['age-years','age-months','age-days','age-next-day-name','age-next-months','age-next-days','bmi-video-table','bmi-video-main']) assert.ok(html.includes(id),id);
  assert.match(js,/function calcAge\(\)[\s\S]*age-next-day-name/);
  assert.match(js,/function calcBodyMetrics\(\)[\s\S]*body-metric-result/);
});

test('BMI inputs enforce the reference three-digit action limit',()=>{
  assert.match(js,/bmi-weight.*bmi-height.*Maximum 3 digits allowed/s);
});

test('currency and unit pickers match reference labels',()=>{
  assert.match(js,/heading\.textContent = isCurrency \? 'Currency' : isUnit \? 'Unit List'/);
  assert.match(js,/searchWrap\) searchWrap\.hidden = !isCurrency/);
});

test('GST and discount reference result rows exist',()=>{
  assert.ok(html.includes('gst-video-result-row'));
  assert.ok(html.includes('id="disc-amount"'));
  assert.match(js,/setElementText\('disc-amount'/);
});

test('Android back action has deterministic tool navigation',()=>{
  assert.match(js,/capApp\?\.addListener/);
  assert.match(js,/goBackFromTool\(\)/);
});
